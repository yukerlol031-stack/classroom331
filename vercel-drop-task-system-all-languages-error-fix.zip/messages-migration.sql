-- Run after setup.sql in Supabase SQL Editor.
create table if not exists public.teacher_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 1000),
  created_at timestamptz not null default now()
);
alter table public.teacher_messages enable row level security;
drop policy if exists "participants read messages" on public.teacher_messages;
create policy "participants read messages" on public.teacher_messages for select to authenticated using (sender_id=auth.uid() or recipient_id=auth.uid());

create or replace function public.send_teacher_message(message_body text,target_student uuid default null)
returns void language plpgsql security definer set search_path = public as $$
declare sender_role text; recipient uuid;
begin
  if char_length(trim(message_body)) not between 1 and 1000 then raise exception 'Сообщение должно содержать от 1 до 1000 символов'; end if;
  select role into sender_role from public.profiles where id=auth.uid();
  if sender_role='student' then
    select teacher_id into recipient from public.profiles where id=auth.uid();
    if recipient is null then raise exception 'Сначала присоединитесь к классу по коду учителя'; end if;
  elsif sender_role='teacher' then
    recipient:=target_student;
    if recipient is null or not exists(select 1 from public.profiles where id=recipient and role='student' and teacher_id=auth.uid()) then raise exception 'Ученик не найден'; end if;
  else raise exception 'Роль пользователя не определена'; end if;
  insert into public.teacher_messages(sender_id,recipient_id,body) values(auth.uid(),recipient,trim(message_body));
end; $$;

do $$ begin
  if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='teacher_messages') then
    alter publication supabase_realtime add table public.teacher_messages;
  end if;
end $$;
