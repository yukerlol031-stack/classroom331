-- Run after shop-migration.sql in Supabase SQL Editor.
alter table public.profiles add column if not exists active_cursor uuid;
alter table public.profiles add column if not exists active_icon uuid;
alter table public.profiles add column if not exists active_theme uuid;
alter table public.shop_items add column if not exists kind text not null default 'icon' check (kind in ('cursor','icon','theme'));
alter table public.shop_items add column if not exists effect text not null default 'icon-orbit';

update public.shop_items set kind='icon',effect='icon-orbit' where name='Лунный значок';
update public.shop_items set kind='cursor',effect='cursor-comet' where name='Комета';
update public.shop_items set kind='icon',effect='icon-saturn' where name='Сатурн';
update public.shop_items set kind='theme',effect='theme-royal' where name='Звёздная корона';
insert into public.shop_items(name,description,price,icon,kind,effect) values
  ('Звёздный курсор','Светящийся курсор-звезда, который работает только в этом сайте.',25,'✦','cursor','cursor-star'),
  ('Неоновый курсор','Яркий курсор-комета для интерфейса сайта.',40,'☄','cursor','cursor-comet'),
  ('Лунные иконки','Мягкое лунное сияние на иконках навигации.',35,'☾','icon','icon-moon'),
  ('Планетарные иконки','Кольца Сатурна вокруг главных иконок.',55,'🪐','icon','icon-saturn'),
  ('Аврора','Переливающаяся тема интерфейса с северным сиянием.',70,'🌌','theme','theme-aurora'),
  ('Королевский космос','Глубокая фиолетовая тема со звёздным свечением.',90,'♛','theme','theme-royal')
on conflict (name) do nothing;

-- Переносит ранее установленный предмет в новый тип украшения.
update public.profiles p set
  active_cursor=case when i.kind='cursor' then p.equipped_item else p.active_cursor end,
  active_icon=case when i.kind='icon' then p.equipped_item else p.active_icon end,
  active_theme=case when i.kind='theme' then p.equipped_item else p.active_theme end
from public.shop_items i
where p.equipped_item=i.id
  and p.equipped_item is not null
  and p.active_cursor is null
  and p.active_icon is null
  and p.active_theme is null;

create or replace function public.equip_shop_item(shop_item_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare item_kind text;
begin
  if not exists(select 1 from public.purchases where user_id=auth.uid() and item_id=shop_item_id) then raise exception 'Сначала купите этот товар'; end if;
  select kind into item_kind from public.shop_items where id=shop_item_id;
  if item_kind='cursor' then update public.profiles set active_cursor=shop_item_id where id=auth.uid();
  elsif item_kind='theme' then update public.profiles set active_theme=shop_item_id where id=auth.uid();
  else update public.profiles set active_icon=shop_item_id where id=auth.uid(); end if;
end; $$;
