-- Run this file if setup.sql was already executed earlier.
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  lesson_date date not null,
  lesson_time time not null,
  topic text not null check (char_length(topic) between 1 and 100),
  comment text not null default '',
  status text not null default 'planned' check (status in ('planned','completed','cancelled')),
  created_at timestamptz not null default now()
);
alter table public.lessons enable row level security;
drop policy if exists "signed in users read lessons" on public.lessons;
drop policy if exists "teachers create lessons" on public.lessons;
drop policy if exists "teachers edit lessons" on public.lessons;
drop policy if exists "teachers delete lessons" on public.lessons;
create policy "signed in users read lessons" on public.lessons for select to authenticated using (true);
create policy "teachers create lessons" on public.lessons for insert to authenticated with check (exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
create policy "teachers edit lessons" on public.lessons for update to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='teacher')) with check (exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
create policy "teachers delete lessons" on public.lessons for delete to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
alter publication supabase_realtime add table public.lessons;
