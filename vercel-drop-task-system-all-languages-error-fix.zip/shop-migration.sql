-- Run after setup.sql and schedule-migration.sql in Supabase SQL Editor.
alter table public.profiles add column if not exists coins integer not null default 0 check (coins >= 0);
alter table public.profiles add column if not exists equipped_item uuid;
alter table public.assignments add column if not exists coins_awarded boolean not null default false;

create table if not exists public.shop_items (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  description text not null default '',
  price integer not null check (price > 0),
  icon text not null default '✦',
  created_at timestamptz not null default now()
);
create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_id uuid not null references public.shop_items(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id,item_id)
);
alter table public.shop_items enable row level security;
alter table public.purchases enable row level security;
create policy "signed in users read shop" on public.shop_items for select to authenticated using (true);
create policy "users read own purchases" on public.purchases for select to authenticated using (user_id=auth.uid());

insert into public.shop_items(name,description,price,icon) values
  ('Лунный значок','Серебристое сияние для профиля.',15,'☾'),
  ('Комета','Быстрый след кометы в вашем кабинете.',30,'☄'),
  ('Сатурн','Планета с кольцами для космического настроения.',50,'🪐'),
  ('Звёздная корона','Редкое украшение для настоящего исследователя.',80,'♛')
on conflict (name) do nothing;

create or replace function public.set_assignment_status(assignment_id uuid,new_status text)
returns void language plpgsql security definer set search_path = public as $$
declare award boolean;
begin
  if new_status not in ('not_started','in_progress','done') then raise exception 'Некорректный статус'; end if;
  update public.assignments set status=new_status,updated_at=now() where id=assignment_id and student_id=auth.uid() returning not coins_awarded into award;
  if not found then raise exception 'Задание не найдено'; end if;
  if new_status='done' and award then
    update public.assignments set coins_awarded=true where id=assignment_id;
    update public.profiles set coins=coins+10 where id=auth.uid();
  end if;
end; $$;

create or replace function public.buy_shop_item(shop_item_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare item_price integer;
begin
  select price into item_price from public.shop_items where id=shop_item_id;
  if item_price is null then raise exception 'Товар не найден'; end if;
  if exists(select 1 from public.purchases where user_id=auth.uid() and item_id=shop_item_id) then raise exception 'Товар уже куплен'; end if;
  update public.profiles set coins=coins-item_price where id=auth.uid() and coins>=item_price;
  if not found then raise exception 'Недостаточно монет'; end if;
  insert into public.purchases(user_id,item_id) values(auth.uid(),shop_item_id);
end; $$;

create or replace function public.equip_shop_item(shop_item_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists(select 1 from public.purchases where user_id=auth.uid() and item_id=shop_item_id) then raise exception 'Сначала купите этот товар'; end if;
  update public.profiles set equipped_item=shop_item_id where id=auth.uid();
end; $$;
