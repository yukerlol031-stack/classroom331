# Космическая система заданий — Supabase + Vercel Drop

## Один раз: настройте базу

1. В Supabase откройте **SQL Editor → New query**.
2. Если база настраивается впервые, скопируйте в редактор всё содержимое `setup.sql` и нажмите **Run**. Если прежняя версия уже была настроена, выполните только `schedule-migration.sql`.
3. Для магазина выполните `shop-migration.sql`. За первое выполнение каждого задания ученику начисляется 10 монет.
4. Для декоративных курсоров, иконок и тем выполните `shop-decor-migration.sql`.
5. Чтобы учитель назначал награду за каждое задание и имел бесконечные монеты, выполните `coin-reward-migration.sql`.
6. Для виртуального казино выполните `casino-migration.sql`.
7. Для сообщений ученика и преподавателя выполните `messages-migration.sql`.

## All-language translation

Add `OPENAI_API_KEY` in Vercel Project → Settings → Environment Variables. The `api/translate.js` function keeps the key on the server and translates interface strings into the scrollable language list. Translation calls use your OpenAI API billing. User messages, assignment descriptions, and lesson content are deliberately excluded from automatic translation.
3. В **Authentication → Providers → Email** при желании отключите подтверждение email для тестов. Для рабочего сайта лучше оставить подтверждение включённым.

## Публикация

Перетащите эту папку или ZIP-архив в [Vercel Drop](https://vercel.com/drop). Сборка и переменные окружения не нужны: используется публичный Supabase publishable key.

## Как пользоваться

1. Преподаватель создаёт аккаунт с ролью «Преподаватель».
2. Его шестизначный код появляется под ником в левом нижнем углу.
3. Ученик создаёт аккаунт с ролью «Ученик», затем нажимает «Присоединиться к классу» и вводит код.
4. Преподаватель выбирает ученика в списке, выдаёт задание и видит статус; ученик может менять только свой статус.

Файлы загружаются в публичное хранилище Supabase. Не добавляйте в них персональные или конфиденциальные данные.
