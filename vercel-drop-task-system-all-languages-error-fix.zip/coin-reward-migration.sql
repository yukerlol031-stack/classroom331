-- Run after shop-migration.sql in Supabase SQL Editor.
alter table public.assignments add column if not exists coin_reward integer not null default 10 check (coin_reward between 1 and 1000);

create or replace function public.set_assignment_status(assignment_id uuid,new_status text)
returns void language plpgsql security definer set search_path = public as $$
declare should_award boolean; reward integer;
begin
  if new_status not in ('not_started','in_progress','done') then raise exception 'Некорректный статус'; end if;
  update public.assignments set status=new_status,updated_at=now()
  where id=assignment_id and student_id=auth.uid()
  returning not coins_awarded, coin_reward into should_award,reward;
  if not found then raise exception 'Задание не найдено'; end if;
  if new_status='done' and should_award then
    update public.assignments set coins_awarded=true where id=assignment_id;
    update public.profiles set coins=coins+reward where id=auth.uid();
  end if;
end; $$;

create or replace function public.buy_shop_item(shop_item_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare item_price integer; is_teacher boolean;
begin
  select price into item_price from public.shop_items where id=shop_item_id;
  if item_price is null then raise exception 'Товар не найден'; end if;
  if exists(select 1 from public.purchases where user_id=auth.uid() and item_id=shop_item_id) then raise exception 'Товар уже куплен'; end if;
  select role='teacher' into is_teacher from public.profiles where id=auth.uid();
  if not is_teacher then
    update public.profiles set coins=coins-item_price where id=auth.uid() and coins>=item_price;
    if not found then raise exception 'Недостаточно монет'; end if;
  end if;
  insert into public.purchases(user_id,item_id) values(auth.uid(),shop_item_id);
end; $$;
