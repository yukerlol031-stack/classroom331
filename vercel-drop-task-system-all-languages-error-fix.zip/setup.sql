-- Run this once in Supabase: SQL Editor → New query → Run.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null default 'Новый пользователь' check (char_length(nickname) between 1 and 30),
  role text not null check (role in ('teacher','student')),
  teacher_id uuid references public.profiles(id) on delete set null,
  invite_code text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 100),
  description text not null default '',
  topic text not null check (char_length(topic) between 1 and 50),
  due_date date not null,
  comment text not null default '',
  link text not null default '',
  file_name text,
  file_url text,
  status text not null default 'not_started' check (status in ('not_started','in_progress','done')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  lesson_date date not null,
  lesson_time time not null,
  topic text not null check (char_length(topic) between 1 and 100),
  comment text not null default '',
  status text not null default 'planned' check (status in ('planned','completed','cancelled')),
  created_at timestamptz not null default now()
);

create or replace function public.create_profile()
returns trigger language plpgsql security definer set search_path = public as $$
declare chosen_role text := coalesce(new.raw_user_meta_data->>'role','student');
begin
  if chosen_role not in ('teacher','student') then chosen_role := 'student'; end if;
  insert into public.profiles (id,nickname,role,invite_code)
  values (new.id,coalesce(nullif(new.raw_user_meta_data->>'nickname',''),'Новый пользователь'),chosen_role,
    case when chosen_role='teacher' then upper(substr(md5(random()::text),1,6)) else null end);
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.create_profile();

create or replace function public.join_teacher(teacher_code text)
returns void language plpgsql security definer set search_path = public as $$
declare found_teacher uuid;
begin
  select id into found_teacher from public.profiles where invite_code=upper(teacher_code) and role='teacher';
  if found_teacher is null then raise exception 'Код приглашения не найден'; end if;
  update public.profiles set teacher_id=found_teacher where id=auth.uid() and role='student';
  if not found then raise exception 'Только ученик может присоединиться к классу'; end if;
end; $$;

create or replace function public.update_my_nickname(new_nickname text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if char_length(trim(new_nickname)) not between 1 and 30 then raise exception 'Никнейм должен содержать от 1 до 30 символов'; end if;
  update public.profiles set nickname=trim(new_nickname) where id=auth.uid();
end; $$;

create or replace function public.set_assignment_status(assignment_id uuid,new_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if new_status not in ('not_started','in_progress','done') then raise exception 'Некорректный статус'; end if;
  update public.assignments set status=new_status,updated_at=now() where id=assignment_id and student_id=auth.uid();
  if not found then raise exception 'Задание не найдено'; end if;
end; $$;

alter table public.profiles enable row level security;
alter table public.assignments enable row level security;
alter table public.lessons enable row level security;
create policy "profiles visible to owner and teacher" on public.profiles for select to authenticated using (id=auth.uid() or teacher_id=auth.uid());
create policy "teacher reads own assignments" on public.assignments for select to authenticated using (teacher_id=auth.uid() or student_id=auth.uid());
create policy "teacher creates assignments" on public.assignments for insert to authenticated with check (teacher_id=auth.uid() and exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
create policy "teacher edits own assignments" on public.assignments for update to authenticated using (teacher_id=auth.uid()) with check (teacher_id=auth.uid());
create policy "teacher deletes own assignments" on public.assignments for delete to authenticated using (teacher_id=auth.uid());
create policy "signed in users read lessons" on public.lessons for select to authenticated using (true);
create policy "teachers create lessons" on public.lessons for insert to authenticated with check (exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
create policy "teachers edit lessons" on public.lessons for update to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='teacher')) with check (exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
create policy "teachers delete lessons" on public.lessons for delete to authenticated using (exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));

alter publication supabase_realtime add table public.lessons;

insert into storage.buckets (id,name,public) values ('assignment-files','assignment-files',true) on conflict (id) do nothing;
create policy "teachers upload files" on storage.objects for insert to authenticated with check (bucket_id='assignment-files' and exists(select 1 from public.profiles where id=auth.uid() and role='teacher'));
create policy "teachers delete own files" on storage.objects for delete to authenticated using (bucket_id='assignment-files' and owner_id=auth.uid()::text);
