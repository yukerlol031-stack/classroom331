-- Optional but recommended: makes shop products English at the database source.
update public.shop_items set name='Moon badge',description='A silver glow for your profile.' where name='Лунный значок';
update public.shop_items set name='Comet',description='A fast comet trail in your workspace.' where name='Комета';
update public.shop_items set name='Saturn',description='A ringed planet for a cosmic mood.' where name='Сатурн';
update public.shop_items set name='Star crown',description='A rare decoration for a true explorer.' where name='Звёздная корона';
update public.shop_items set name='Star cursor',description='A glowing star cursor that works only on this site.' where name='Звёздный курсор';
update public.shop_items set name='Neon cursor',description='A bright comet cursor for the site interface.' where name='Неоновый курсор';
update public.shop_items set name='Moon icons',description='Soft moonlight on navigation icons.' where name='Лунные иконки';
update public.shop_items set name='Planet icons',description='Saturn rings around main icons.' where name='Планетарные иконки';
update public.shop_items set name='Aurora',description='A shimmering interface theme with northern lights.' where name='Аврора';
update public.shop_items set name='Royal space',description='A deep purple theme with star glow.' where name='Королевский космос';
