-- Run after coin-reward-migration.sql in Supabase SQL Editor.
create table if not exists public.casino_games (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  bet_amount integer not null check (bet_amount > 0),
  outcome text not null check (outcome in ('win','lose')),
  created_at timestamptz not null default now()
);
alter table public.casino_games enable row level security;
drop policy if exists "users read own casino games" on public.casino_games;
create policy "users read own casino games" on public.casino_games for select to authenticated using (user_id=auth.uid());

create or replace function public.place_coin_bet(bet_amount integer)
returns text language plpgsql security definer set search_path = public as $$
declare current_coins integer; result text;
begin
  if bet_amount is null or bet_amount < 1 then raise exception 'Ставка должна быть не меньше 1 монеты'; end if;
  if (select role from public.profiles where id=auth.uid()) <> 'student' then raise exception 'Казино доступно только ученику'; end if;
  select coins into current_coins from public.profiles where id=auth.uid() for update;
  if bet_amount > current_coins then raise exception 'Ставка не может быть больше баланса'; end if;
  result := case when random() < 0.5 then 'win' else 'lose' end;ф
  if result='win' then
    update public.profiles set coins=coins+bet_amount where id=auth.uid();
  else
    update public.profiles set coins=coins-bet_amount where id=auth.uid();
  end if;
  insert into public.casino_games(user_id,bet_amount,outcome) values(auth.uid(),bet_amount,result);
  return result;
end; $$;

-- Обновляет cache API Supabase, чтобы функция стала доступна сразу.
notify pgrst, 'reload schema';
